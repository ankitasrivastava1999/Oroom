<html>
<link rel="stylesheet" href="scss/foundation.css">
<link rel="stylesheet" href="scss/style.css">
<link href='http://fonts.googleapis.com/css?family=Slabo+13px' rel='stylesheet' type='text/css'>
<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="icon/css/fontello.css">
<body style="margin-top: 50px; margin-left:auto; margin-right:auto; padding-left:auto; padding-right:auto; width: 70%;">
				<p align="center">
					<h6 align="center">Somehow we didn't received your payment due an error.<br><b>If you already made payment through Paypal, Please contact us at 000-000-00 or email to info@gamboh.com.my</b></h6>
				</p>				

				
				
		</td>
		<td></td>
	</tr>
</table>
</body></html>
